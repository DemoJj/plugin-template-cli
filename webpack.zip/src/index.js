import component from './main.vue'
var MyComponent = {
    install: function install(Vue){
        Vue.component('my-component', component)
    },
    component
}

if(window.Vue){
    Vue.use(MyComponent)
}
console.log(111)

export default MyComponent