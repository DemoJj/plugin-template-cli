<template>
    <div>
        {{msg}}
    </div>
</template>

<script>
    export default {
        data(){
            return {
                msg:1
            }
        }
    }
</script>

<style lang="less" scoped>

</style>