const Path = require('path')
const pcg = require('./package.json')

const VueLoaderPlugin = require('vue-loader/lib/plugin')
const SimpleProgressWebpackPlugin = require('simple-progress-webpack-plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')

function resolve(dir) {
    return Path.join(__dirname, '.', dir)
}

const OutputName = `${pcg.name}-${pcg.version}.js`

module.exports = {
    entry: resolve('src/index.js'),
    output: {
        path: resolve('dist'),
        filename: OutputName,
        libraryTarget: 'umd',
        libraryExport: 'default',
        library: pcg.name.split('-').map(o => o.slice(0, 1).toUpperCase() + o.slice(1)).join('') // 短横线命名转帕斯卡命名
    },
    mode: 'development',
    resolve: {
        extensions: ['.js', '.vue']
    },
    module: {
        rules: [
            {
                test: /\.vue$/,
                loader: 'vue-loader'
            },
            {
                test: /\.css$/,
                use: [
                    'style-loader',
                    'css-loader'
                ]
            },
            {
                test: /\.less$/,
                use: [
                    'style-loader',
                    'css-loader',
                    'less-loader'
                ]
            },
            {
                test: /\.(png|jpe?g|gif|svg)(\?.*)?$/,
                loader: 'url-loader'
            },
            {
                test: /\.(woff2?|eot|ttf|otf)(\?.*)?$/,
                loader: 'url-loader'
            }
        ]
    },
    plugins: [
        new VueLoaderPlugin(), // vue加载插件
        new SimpleProgressWebpackPlugin(), // 打包进度插件
        new HtmlWebpackPlugin({
            title: 'Test Page',
            filename: 'index.html',
            template: 'test/test.html',
            inject: false,
            bundle: OutputName
        })
    ]
}