let b = 'hello word'
let a = b
console.log(b,1)
console.log(a===b)