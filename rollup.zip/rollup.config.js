const pcg = require('./package.json')
const resolve = require('rollup-plugin-node-resolve');
const commonjs = require('rollup-plugin-commonjs')
const {
    terser
} = require('rollup-plugin-terser')
const serve = require('rollup-plugin-serve');
const livereload = require('rollup-plugin-livereload');
// const html = require('@rollup/plugin-html');
const html = require('./lib/rollup-html-plugin.js');
const babel = require('rollup-plugin-babel');

var definePlugins = [
    commonjs(), // 解析commonjs语法
    resolve(), // 获取node_modules依赖包
    babel({
        exclude: 'node_modules/**'
    }),
    terser() // 压缩
]
const OutputName = `${pcg.name}-${pcg.version}.js`

// 判断是否为watch
if (~process.argv.indexOf('--watch')) {
    definePlugins = definePlugins.concat([
        html({
            fileName: 'index.html',
            title: 'Test Page',
            templateObj: {
                temp: './test/test.html',
                options: {
                    bundle: OutputName
                }
            }
        }),
        livereload({
            watch: 'src'
        }), // 热更新
        serve({ // 启动服务
            open: true,
            port: 8000,
            openPage: '/dist/index.html' // 打开的页面
        })
    ])
}

module.exports = {
    input: './src/index.js',
    output: {
        file: `./dist/${OutputName}`,
        format: 'umd',
        name: pcg.name.split('-').map(o=>o.slice(0,1).toUpperCase()+o.slice(1)).join('') // 短横线命名转帕斯卡命名
    },
    plugins: definePlugins
}